﻿'use strict';

//angular.module("dealerApp").service('StandingDryLog', ['$http', function ($http) {

//    var urlBase = '/api/StandingDryLog';
//    //Create new record
//    this.getStandingDryLogs = function (StandingDryLog) {
//        var request = $http({
//            method: "post",
//            url: urlBase,
//            data: StandingDryLog
//        });
//        return request;
//    }  
//    //Get All  StandingDryLogs
//   this.getAllLogs = function () {
//       return $http.get(urlBase);
//  }
//}]);